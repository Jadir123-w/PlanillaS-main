package db;

public class Db {

    public Db(String db) {

    }

    public void Sentencia(String sql) {

    }

    public String[] getRegistro() {
        //return null;
        return new String[] {"1", "Omar", "Espinoza", "Manrique", "99887766", "123456", "17/09/1973", "Mi casa", "1", "1", "1", "1"};
    }

}
