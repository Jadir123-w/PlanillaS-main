package controller;

public class CargoDAO {

}
